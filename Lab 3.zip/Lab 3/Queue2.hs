module Queue (Queue, mtq, ismt, addq, remq) where

---- Interface ----------------
mtq  :: Queue a                  -- empty queue
ismt :: Queue a -> Bool          -- is the queue empty?
addq :: a -> Queue a -> Queue a  -- add element to front of queue
remq :: Queue a -> (a, Queue a)  -- remove element from back of queue;
                                 --   produces error on empty

---- Implementation -----------
data Queue a = Queue2 [a] [a]

mtq = Queue2 [] []
ismt (Queue2 xs ys) = null xs && null ys
addq x (Queue2 xs ys) = Queue2 (x:xs) ys
remq (Queue2 xs (y:ys)) = (y, Queue2 xs ys)
remq (Queue2 xs []) = remq (Queue2 [] (reverse xs))
