module Queue (Queue, mtq, ismt, addq, remq) where

---- Interface ----------------
mtq  :: Queue a                  -- empty queue
ismt :: Queue a -> Bool          -- is the queue empty?
addq :: a -> Queue a -> Queue a  -- add element to front of queue
remq :: Queue a -> (a, Queue a)  -- remove element from back of queue;
                                 --   produces error on empty
---- Implementation -----------
data Queue a = Queue [a]

mtq = Queue []
ismt (Queue xs) = null xs
addq x (Queue xs) = Queue (x:xs)
remq (Queue xs) = (remLast xs, Queue (init xs))

---- Helper(s) -----------------
remLast :: [a] -> a
remLast [] = error "The list is empty."
remLast xs = last xs
