
--Haskell iterative version of fib
fib:: Int -> Int
fib x = fib_it x 1 1 where
    fib_it :: Int -> Int -> Int -> Int
    fib_it 0 a b = a
    fib_it 1 a b = b
    fib_it n a b = fib_it (n-1) b (a+b)
