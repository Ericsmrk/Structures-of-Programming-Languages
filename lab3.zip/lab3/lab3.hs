-- CSci 117, Lab 3:  ADTs and Type Classes

import Data.List (sort)
import Queue
import Fraction

---------------- Part 1: Queue client

-- add a list of elements, in order, into a queue
adds :: [a] -> Queue a -> Queue a
adds [x] q = (addq x q)
adds xs q = (addq (last xs) (adds (init xs) q))

-- remove all elements of the queue, putting them into a list
rems :: Queue a -> [a]
rems q = if ismt q
         then []
         else let (x,xs) = remq q
              in  (x:rems xs)

-- test whether adding a list of elements to an initially empty queue
-- and then removing them produces the same list (FIFO)
testq :: Eq a => [a] -> Bool
testq xs = let q = (adds xs mtq)
           in (xs == rems q)

---------------- Part 2: Using typeclass instances for fractions

-- Construct a fraction and produce an error if it fails
frac' :: Integer -> Integer -> Fraction
frac' a b = case frac a b of
             Nothing -> error "Illegal fraction"
             Just fr -> fr


-- Calculate the average of a list of fractions (give error if xs is empty)
average :: [Fraction] -> Fraction
average [] = error "Empty list."
average xs = (sum (xs)) * (frac' 1 (toInteger (length xs)))

-- Some lists of fractions

list1 = [frac' n (n+1) | n <- [1..20]]
list2 = [frac' 1 n | n <- [1..20]]
list3 = zipWith (+) list1 list2
-- Make up several more lists for testing
list4 = [frac' (n*2) (n+2) | n <- [1..10]]
list5 = [frac' (n+3) n | n <- take 20 (cycle [1..7])]
list6 = [frac' n (n-1) | n <- filter even [1..30]]
list7 = [frac' n (n-1) | n <- filter odd [2..30]]
list8 = [frac' (n*n) (n+3*n-1) | n <- take 40 [1..]]
list9 = filter (>1) $ concat [list1, list2, list3, list4]
list10 = filter (<1) $ concat [list1, list2, list3, list4]
list11 = [frac' (n+1) 1 | n <- [1..5]]
listmt = []

-- Show examples testing the functions sort, sum, product, maximum, minimum,
-- and average on a few lists of fractions each. Think about how these library
-- functions can operate on Fractions, even though they were written long ago

{------sort------
*Main> sort list1
[1/2,2/3,3/4,4/5,5/6,6/7,7/8,8/9,9/10,10/11,11/12,
12/13,13/14,14/15,15/16,16/17,17/18,18/19,19/20,20/21]
*Main> list1
[1/2,2/3,3/4,4/5,5/6,6/7,7/8,8/9,9/10,10/11,11/12,
12/13,13/14,14/15,15/16,16/17,17/18,18/19,19/20,20/21]
*Main> sort list2
[1/20,1/19,1/18,1/17,1/16,1/15,1/14,1/13,1/12,1/11,
1/10,1/9,1/8,1/7,1/6,1/5,1/4,1/3,1/2,1/1]
*Main> list2
[1/1,1/2,1/3,1/4,1/5,1/6,1/7,1/8,1/9,1/10,1/11,1/12,
1/13,1/14,1/15,1/16,1/17,1/18,1/19,1/20]
-}

{------sum------
*Main> list11
[2/1,3/1,4/1,5/1,6/1]
*Main> sum list11
20/1
*Main> list6
[2/1,4/3,6/5,8/7,10/9,12/11,14/13,16/15,18/17,20/19,22/21,24/23,
26/25,28/27,30/29]
*Main> sum list6
107313963788782800/6190283353629375
-}

{------product------
*Main> list5
[4/1,5/2,2/1,7/4,8/5,3/2,10/7,4/1,5/2,2/1,7/4,8/5,3/2,10/7,4/1,5/2,2/1,
7/4,8/5,3/2]
*Main> product list5
30346444800000/25088000
*Main> list10
[1/2,2/3,3/4,4/5,5/6,6/7,7/8,8/9,9/10,10/11,11/12,12/13,13/14,14/15,15/16,
16/17,17/18,18/19,19/20,20/21,1/2,1/3,1/4,1/5,1/6,1/7,1/8,1/9,1/10,1/11,
1/12,1/13,1/14,1/15,1/16,1/17,1/18,1/19,1/20,2/3]
*Main> product list10
4865804016353280000/372897767427565444181298826444800000000
*Main> list11
[2/1,3/1,4/1,5/1,6/1]
*Main> product list11
720/1
-}

{------maximum------
*Main> list9
[3/2,7/6,13/12,21/20,31/30,43/42,57/56,73/72,91/90,111/110,133/132,157/156,
183/182,211/210,241/240,273/272,307/306,343/342,381/380,421/420,6/5,4/3,10/7,
3/2,14/9,8/5,18/11,5/3]
*Main> maximum list9
5/3
*Main> list8
[1/3,4/7,9/11,16/15,25/19,36/23,49/27,64/31,81/35,100/39,121/43,144/47,169/51
,196/55,225/59,256/63,289/67,324/71,361/75,400/79,441/83,484/87,529/91,576/95,
625/99,676/103,729/107,784/111,841/115,900/119,961/123,1024/127,1089/131,
1156/135,1225/139,1296/143,1369/147,1444/151,1521/155,1600/159]
*Main> maximum list8
1600/159
*Main> list6
[2/1,4/3,6/5,8/7,10/9,12/11,14/13,16/15,18/17,20/19,22/21,24/23,26/25,28/27,
30/29]
*Main> maximum list6
2/1
-}

{------minimum------
*Main> list7
[3/2,5/4,7/6,9/8,11/10,13/12,15/14,17/16,19/18,21/20,23/22,25/24,27/26,29/28]
*Main> minimum list7
29/28
*Main> list6
[2/1,4/3,6/5,8/7,10/9,12/11,14/13,16/15,18/17,20/19,22/21,24/23,26/25,28/27,30/29]
*Main> minimum list6
30/29
*Main> list5
[4/1,5/2,2/1,7/4,8/5,3/2,10/7,4/1,5/2,2/1,7/4,8/5,3/2,10/7,4/1,5/2,2/1,7/4,8/5,3/2]
*Main> minimum list5
10/7
*Main> minimum list11
2/1
*Main> list11
[2/1,3/1,4/1,5/1,6/1]
-}

{------average------
*Main> list3
[3/2,7/6,13/12,21/20,31/30,43/42,57/56,73/72,91/90,111/110,133/132,157/156,183/182,211/210,241/240,273/272,307/306,343/342,381/380,421/420]
*Main> average list3
22/21
*Main> listmt
[]
*Main> average listmt
*** Exception: Empty list.
CallStack (from HasCallStack):
  error, called at lab3.hs:34:14 in main:Main
*Main> list11
[2/1,3/1,4/1,5/1,6/1]
*Main> average list11
4/1
-}
